package game;

import java.util.LinkedList;

public class Snake {
    private LinkedList<int[]> body; // List of [x, y] coordinates
    private String direction; // "UP", "DOWN", "LEFT", "RIGHT"
    private final int id; // Unique ID for the player

    public Snake(int startX, int startY, String initialDirection, int id) {
        body = new LinkedList<>();
        body.add(new int[]{startX, startY});
        direction = initialDirection;
        this.id = id;
    }

    public LinkedList<int[]> getBody() {
        return body;
    }

    public void move(int x, int y) {
        body.addFirst(new int[]{x, y});
    }

    public void grow() {
        // No action needed; just retain tail during move
    }

    public void shrink() {
        body.removeLast();
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public int getId() {
        return id;
    }
}
