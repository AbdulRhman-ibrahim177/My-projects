package game;

import javax.swing.*;
import threads.CollisionDetectionThread;
import threads.InputThread;
import threads.MovementThread;
import threads.ScoreUpdateThread;

public class SnakeGame extends JFrame {
    private static final int WIDTH = 600;
    private static final int HEIGHT = 600;
    private static final int CELL_SIZE = 20;

    private final GameBoard board;
    private final Snake player1;
    private final Snake player2;

    private final MovementThread movementThread1;
    private final MovementThread movementThread2;
    private final InputThread inputThread;
    private final CollisionDetectionThread collisionThread;
    private final ScoreUpdateThread scoreThread;

    private boolean player1Dead = false;
    private boolean player2Dead = false;

    public SnakeGame() {
        board = new GameBoard(WIDTH / CELL_SIZE, HEIGHT / CELL_SIZE);

        player1 = new Snake(5, 5, "RIGHT", 1);
        player2 = new Snake(15, 15, "LEFT", 2);

        board.spawnFood();

        movementThread1 = new MovementThread(player1, board, this);
        movementThread2 = new MovementThread(player2, board, this);
        inputThread = new InputThread(player1, player2);
        collisionThread = new CollisionDetectionThread(player1, player2, board, this);
        scoreThread = new ScoreUpdateThread(player1, player2);

        setupUI();

        startThreads();
    }

    private void setupUI() {
        setTitle("Multiplayer Snake Game");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        // Pass the scoreThread to GamePanel
        GamePanel gamePanel = new GamePanel(board, CELL_SIZE, scoreThread);
        add(gamePanel);

        addKeyListener(inputThread);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);

        Timer timer = new Timer(100, e -> gamePanel.repaint());
        timer.start();

        setVisible(true);
    }

    private void startThreads() {
        movementThread1.start();
        movementThread2.start();
        inputThread.start();
        collisionThread.start();
        scoreThread.start();
    }

    public void triggerGameOver() {
        // Stop all threads
        inputThread.stopThread();
        collisionThread.stopThread();
        scoreThread.stopThread();
        movementThread1.stopThread();
        movementThread2.stopThread();

        // Show "Game Over" dialog
        SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(this,
                    "Game Over!\nPlayer 1 Score: " + scoreThread.getPlayer1Score() +
                            "\nPlayer 2 Score: " + scoreThread.getPlayer2Score(),
                    "Game Over", JOptionPane.INFORMATION_MESSAGE);

            System.exit(0); // End the game
        });
    }

    public void snakeKilled(int playerId) {
        if (playerId == 1) {
            player1Dead = true;
        } else if (playerId == 2) {
            player2Dead = true;
        }

        // If both players are dead, trigger game over
        if (player1Dead && player2Dead) {
            triggerGameOver();
        }
    }
}
