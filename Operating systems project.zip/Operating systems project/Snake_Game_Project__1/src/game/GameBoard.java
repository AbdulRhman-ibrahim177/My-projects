package game;

import java.util.HashMap;
import java.util.Map;

public class GameBoard {
    private final int rows;
    private final int cols;
    private int[][] board; // 0 = empty, 1 = snake1, 2 = snake2, 3 = food
    private final Map<Integer, String> playerColors; // Mapping player ID to their colors

    public GameBoard(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        board = new int[rows][cols];
        playerColors = new HashMap<>();
        initializePlayerColors();
    }

    private void initializePlayerColors() {
        playerColors.put(1, "BLUE");
        playerColors.put(2, "RED");
    }

    public synchronized void setCell(int x, int y, int value) { // bta50d el cell position w value which is the state of the cell w btb2a sync 3shan my7slash collision fe elread bin el 2 users
        board[x][y] = value;
    }

    public synchronized int getCell(int x, int y) {
        return board[x][y];
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }


    public synchronized void spawnFood() {
        int x, y;
        do {
            // Generate random positions within a "safe" range (not on the border)
            x = 1 + (int) (Math.random() * (rows - 2));
            y = 1 + (int) (Math.random() * (cols - 2));
        } while (board[x][y] != 0); // Ensure food spawns in an empty cell
        board[x][y] = 3; // Mark food position
    }


    public synchronized String getPlayerColor(int playerId) {
        return playerColors.get(playerId);
    }
}
