package game;

import threads.ScoreUpdateThread;

import javax.swing.*;
import java.awt.*;

public class GamePanel extends JPanel {
    private final GameBoard board;
    private final int cellSize;
    private final ScoreUpdateThread scoreThread;  // Reference to ScoreUpdateThread

    public GamePanel(GameBoard board, int cellSize, ScoreUpdateThread scoreThread) {
        this.board = board;
        this.cellSize = cellSize;
        this.scoreThread = scoreThread;
        setDoubleBuffered(true); // Enable double buffering
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the game board
        for (int i = 0; i < board.getRows(); i++) {
            for (int j = 0; j < board.getCols(); j++) {
                if (board.getCell(i, j) == 1) {
                    g.setColor(Color.BLUE);
                } else if (board.getCell(i, j) == 2) {
                    g.setColor(Color.RED);
                } else if (board.getCell(i, j) == 3) {
                    g.setColor(Color.GREEN);
                } else {
                    g.setColor(Color.BLACK);
                }
                g.fillRect(j * cellSize, i * cellSize, cellSize, cellSize);
            }
        }

        // Draw the score
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString("Player 1 Score: " + scoreThread.getPlayer1Score(), 10, 20);  // Draw player 1 score
        g.drawString("Player 2 Score: " + scoreThread.getPlayer2Score(), getWidth() - 150, 20);  // Draw player 2 score
    }
}
