package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartMenu extends JFrame {
    private static final int WIDTH = 600;
    private static final int HEIGHT = 600;

    public StartMenu() {
        setTitle("Snake Game - Start Menu");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        // Add custom panel for background image
        BackgroundPanel backgroundPanel = new BackgroundPanel("src/snakePhoto.jpg"); // Replace with your image path
        backgroundPanel.setLayout(new BorderLayout());
        add(backgroundPanel);

        // Add "Start Game" button
        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.setBackground(Color.GREEN);
        startButton.setFocusPainted(false);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the start menu
                new SnakeGame(); // Start the game
            }
        });

        // Center button in the panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false); // Transparent background
        buttonPanel.add(startButton);
        backgroundPanel.add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        new StartMenu(); // Launch the start menu
    }

    // Custom panel to display a scaled background image
    private static class BackgroundPanel extends JPanel {
        private final Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            this.backgroundImage = new ImageIcon(imagePath).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Scale image to fit the panel dimensions
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
