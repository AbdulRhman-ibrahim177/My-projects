package threads;

import game.Snake;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class InputThread extends Thread implements KeyListener {
    private final Snake player1;
    private final Snake player2;
    private boolean running = true;

    public InputThread(Snake player1, Snake player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    @Override
    public void run() {
        while (running) {
            // This thread runs to listen for inputs in the background.
            // Actual input handling is in the `keyPressed` method.
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        synchronized (player1) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W -> player1.setDirection("UP");
                case KeyEvent.VK_S -> player1.setDirection("DOWN");
                case KeyEvent.VK_A -> player1.setDirection("LEFT");
                case KeyEvent.VK_D -> player1.setDirection("RIGHT");
            }
        }
        synchronized (player2) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP -> player2.setDirection("UP");
                case KeyEvent.VK_DOWN -> player2.setDirection("DOWN");
                case KeyEvent.VK_LEFT -> player2.setDirection("LEFT");
                case KeyEvent.VK_RIGHT -> player2.setDirection("RIGHT");
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) { }

    @Override
    public void keyTyped(KeyEvent e) { }

    public void stopThread() {
        running = false;
    }
}
