package threads;

import game.GameBoard;
import game.Snake;
import game.SnakeGame;

public class MovementThread extends Thread {
    private final Snake snake;
    private final GameBoard board;
    private final SnakeGame game;
    private boolean running = true;

    public MovementThread(Snake snake, GameBoard board, SnakeGame game) {
        this.snake = snake;
        this.board = board;
        this.game = game;
    }

    @Override
    public void run() {
        while (running) {
            synchronized (board) {
                // Calculate new head position
                int[] head = snake.getBody().getFirst();
                int x = head[0], y = head[1];
                switch (snake.getDirection()) {
                    case "UP": x--; break;
                    case "DOWN": x++; break;
                    case "LEFT": y--; break;
                    case "RIGHT": y++; break;
                }

                // Check if the position is valid
                if (x >= 0 && x < board.getRows() && y >= 0 && y < board.getCols()) {
                    int cellValue = board.getCell(x, y);

                    boolean hasEaten = false;

                    // Handle collisions with food
                    if (cellValue == 3) {
                        snake.grow();
                        board.spawnFood();
                        hasEaten = true;
                    } else if (cellValue != 0) {
                        running = false; // Collision with another snake or wall
                        game.snakeKilled(snake.getId()); // Notify the game that this snake is dead
                        return;
                    }

                    // Update the board and snake body
                    board.setCell(x, y, snake.getId());
                    snake.move(x, y);

                    // Remove tail unless it grew
                    if (!hasEaten) {
                        int[] tail = snake.getBody().getLast();
                        board.setCell(tail[0], tail[1], 0); // Clear the tail on the board
                        snake.shrink();
                    }
                } else {
                    running = false; // Snake hit the wall
                    game.snakeKilled(snake.getId()); // Notify the game that this snake is dead
                }
            }

            try {
                Thread.sleep(200); // Control movement speed
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void stopThread() {
        running = false;
    }
}
