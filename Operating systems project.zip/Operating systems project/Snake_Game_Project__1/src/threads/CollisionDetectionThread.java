package threads;

import game.GameBoard;
import game.Snake;
import game.SnakeGame;

public class CollisionDetectionThread extends Thread {
    private final Snake player1;
    private final Snake player2;
    private final GameBoard board;
    private final SnakeGame game;  // Add SnakeGame reference
    private boolean running = true;

    public CollisionDetectionThread(Snake player1, Snake player2, GameBoard board, SnakeGame game) {
        this.player1 = player1;
        this.player2 = player2;
        this.board = board;
        this.game = game;  // Initialize the SnakeGame reference
    }

    @Override
    public void run() {
        while (running) {
            synchronized (board) {
                checkCollision(player1);
                checkCollision(player2);
                checkSnakeCollision();
            }

            try {
                Thread.sleep(100); // Adjust collision checking interval
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void checkCollision(Snake snake) {
        int[] head = snake.getBody().getFirst();
        int x = head[0], y = head[1];

        // Check wall collision
        if (x < 0 || x >= board.getRows() || y < 0 || y >= board.getCols()) {
            game.snakeKilled(snake.getId()); // Notify the game that the snake is dead
        }

        // Check body collision
        for (int i = 1; i < snake.getBody().size(); i++) {
            int[] segment = snake.getBody().get(i);
            if (segment[0] == x && segment[1] == y) {
                game.snakeKilled(snake.getId()); // Notify the game that the snake is dead
            }
        }

        // Check food collision
        if (board.getCell(x, y) == 3) {
//            snake.grow();
            board.spawnFood();
        }
    }

    private void checkSnakeCollision() {
        int[] head1 = player1.getBody().getFirst();
        int[] head2 = player2.getBody().getFirst();

        if (head1[0] == head2[0] && head1[1] == head2[1]) {
            game.snakeKilled(player1.getId());  // Notify game if snake 1 collides with snake 2
            game.snakeKilled(player2.getId());  // Notify game if snake 2 collides with snake 1
        }
    }

    public void stopThread() {
        running = false;
    }
}
