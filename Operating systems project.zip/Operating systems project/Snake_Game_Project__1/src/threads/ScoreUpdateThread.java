package threads;

import game.Snake;

public class ScoreUpdateThread extends Thread {
    private final Snake player1;
    private final Snake player2;
    private int player1Score = 0;
    private int player2Score = 0;
    private boolean running = true;

    public ScoreUpdateThread(Snake player1, Snake player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    @Override
    public void run() {
        while (running) {
            synchronized (player1) {
                player1Score = player1.getBody().size() - 1;
            }
            synchronized (player2) {
                player2Score = player2.getBody().size() - 1;
            }

            try {
                Thread.sleep(1000); // Update every second
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public int getPlayer1Score() {
        return player1Score;
    }

    public int getPlayer2Score() {
        return player2Score;
    }

    public void stopThread() {
        running = false;
    }
}
